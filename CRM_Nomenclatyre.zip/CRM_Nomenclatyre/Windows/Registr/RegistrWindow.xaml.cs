﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CRM_Nomenclatyre.Windows.Registr
{
    /// <summary>
    /// Логика взаимодействия для RegistrWindow.xaml
    /// </summary>
    public partial class RegistrWindow : Window
    {
        public RegistrWindow()
        {
            InitializeComponent();
        }

        private void bt_Reg_Click(object sender, RoutedEventArgs e)
        {
            tb_FirstName.Text = "";
            tb_LasttName.Text = "";
            tb_Login.Text = "";
            tb_Password.Text = "";
        }
    }
}
